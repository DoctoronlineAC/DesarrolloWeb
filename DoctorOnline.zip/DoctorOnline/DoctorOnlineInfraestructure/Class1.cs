﻿using System;

namespace DoctorOnlineInfraestructure
{
    public class Class1
    {
    }
}
