﻿using System;

namespace DoctorOnlineCore
{
    public class Class1
    {
    }
}
